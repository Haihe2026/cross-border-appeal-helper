"""无外部依赖的确定性对话控制器。真实政策未知时关闭生成门禁。"""
import copy
import html
import json
import re
import uuid
from pathlib import Path

PLATFORMS = ['亚马逊', 'TikTok Shop', 'Temu']
COUNTRIES = ['美国', '英国', '德国', '澳洲']
TYPES = ['平台索赔 / 纠纷', '退货退款纠纷', '卖家反馈移除 / 删除线', '拒付 / 退款抗辩证据包']
FIELDS = ['订单号', '金额', '发货时间', '签收时间', '物流单号', '退货状态', '是否已退款']
LOCK = '账号解封申诉功能即将开放，升级后解锁，首版暂不受理。'
PAY = '免费试用已用完，请通过自有支付后端购买权益后再开始。'
RISK = {
    '施压买家': ['撤诉', 'pressure', 'force the buyer', 'zwingen'],
    '奖励删评': ['奖励删评', '好评返现', 'reward', 'remove your review', 'Belohnung'],
    '编造事实': ['编造', '伪造', 'fabricat', 'fake evidence', 'gefälscht'],
    '法律威胁': ['起诉', '法律威胁', 'sue', 'legal action', 'verklagen'],
    '情绪化措辞': ['骗子', '欺诈买家', 'liar', 'scammer', 'Betrüger'],
}


def safe(value):
    return html.escape(str(value)).replace('|', '&#124;').replace('\n', '<br>')


def scan(text):
    rows = []
    for name, words in RISK.items():
        found = [w for w in words if w.casefold() in text.casefold()]
        if found:
            rows.append(f'|{name}|<span style="color:red">{safe("、".join(found))}</span>|删除该表述，改为：请依据本单已确认事实与原始证据复核。|')
        else:
            rows.append(f'|{name}|未发现词表命中；仍需人工复核|—|')
    return '|项目|结果|改写|\n|---|---|---|\n' + '\n'.join(rows)


class Session:
    def __init__(self, ledger, identity, policies=None, previous=None):
        self.ledger, self.identity = ledger, identity
        self.policies = policies if policies is not None else json.loads((Path(__file__).parents[1] / 'references/policies.json').read_text())
        self.previous = copy.deepcopy(previous or {})
        self.state = 0
        self.data = {'facts': {}, 'evidence': {}}
        self.pending = None
        self.field = 0
        self.repair = False
        self.repair_field = False
        self.sections = []
        self.request_id = str(uuid.uuid4())
        self.revision = None

    def start(self):
        if not self.ledger.status(self.identity)['allowed']:
            self.state = -1
            return PAY
        self.state = 1
        return self.prompt()

    def records(self):
        return [p for p in self.policies if p['platform'] == self.data.get('platform') and p['country'] == self.data.get('country')]

    def policy(self):
        return next((p for p in self.records() if p['type'] == self.data.get('type')), None)

    def prompt(self):
        if self.pending is not None:
            return f'你提供的是：{safe(self.pending[1])}。我理解对吗？（确认 / 不对）'
        if self.state == 1:
            return '先选平台：1 亚马逊 2 TikTok Shop 3 Temu。你做的是哪个平台？'
        if self.state == 2:
            return '再选国家：1 美国 2 英国 3 德国 4 澳洲。这个订单是哪个国家的站点？'
        if self.state == 3:
            return '纠纷是哪一种？1 平台索赔 / 纠纷 2 退货退款纠纷 3 卖家反馈移除 / 删除线 4 拒付 / 退款抗辩证据包 5 账号解封申诉。'
        if self.state == 4:
            return '把平台发来的通知 / 买家消息 / 反馈原文粘贴给我，只贴本单的。（本地工具用“订单号：…\\n纠纷原因：…”标识原文中的对应项）'
        if self.state == 5:
            return FIELDS[self.field] + '是多少？' if self.field < 2 else FIELDS[self.field] + '？'
        if self.state == 6:
            items = self.policy()['evidence_by_reason'][self.data['reason']]
            return '按你这个平台、国家、纠纷类型，需要的证据是下面这些，你手头有的打勾，没有的我标待补。\n' + '\n'.join(f'{i+1}. {x}' for i, x in enumerate(items)) + '\n请逐项标注（可多选）：已有 / 待补 / 不适用；本地工具格式为“1=已有;2=待补”。'
        if self.state == 7:
            trial = '这是你的免费 1 次，确认后生成即算用完。' if self.ledger.status(self.identity)['free'] else '本次使用已购买的权益，确认生成后计用一次。'
            rows = [('平台', self.data['platform']), ('国家', self.data['country']), ('纠纷类型', self.data['type']), ('时限', '以平台通知为准'), ('证据清单', json.dumps(self.data['evidence'], ensure_ascii=False)), ('申诉要点', self.data['reason'])]
            return '生成前先跟你对一遍\n\n|项目|内容|\n|---|---|\n' + '\n'.join(f'|{k}|{safe(v)}|' for k,v in rows) + '\n' + trial + '\n以上确认吗？（确认 / 改）'
        if self.state == 9:
            if self.revision:
                return f'第 {self.revision} 段要调整什么措辞？（事实变更须返回对应步骤）'
            return '要改哪一段？只改一段的话，我只重扫该段。（1–4 / 就这样）'
        return '本轮已结束。'

    def offer(self, key, value, summary=None):
        self.pending = (key, value)
        return f'你提供的是：{safe(summary if summary is not None else value)}。我理解对吗？（确认 / 不对）'

    def invalid(self):
        return '先完成这一步，我再帮你往下走。\n' + self.prompt()

    def step(self, text):
        text = text.strip()
        if text == '退出':
            self.data = {'facts': {}, 'evidence': {}}
            self.pending = None
            self.sections = []
            self.state = -1
            return '本轮已结束，重进须从选平台开始。'
        if self.state <= 0:
            return '本轮已结束，请重新开始。'
        if text == '返回上一步':
            self.pending = None
            self.sections = []
            self.repair = False
            if self.state == 5 and self.field:
                self.field -= 1
            else:
                self.state = max(1, self.state - 1 if self.state != 9 else 7)
                if self.state == 5:
                    self.field = 6
            return self.prompt()
        if self.pending is not None:
            if text == '不对':
                self.pending = None
                return self.prompt()
            if text != '确认':
                return self.invalid()
            key, val = self.pending
            self.pending = None
            return self.accept(key, val)
        if text in ('随便写', '你看着办', '直接出信', '确认') and self.state != 7:
            return self.invalid()
        if text == '同上':
            key = {1:'platform', 2:'country'}.get(self.state)
            if not key or key not in self.previous:
                return self.invalid()
            return self.offer(key, self.previous[key])
        if self.state in (1,2,3):
            if self.state == 3 and text in ('5', '账号解封申诉'):
                self.state = -1
                self.data = {'facts': {}, 'evidence': {}}
                return LOCK
            options = {1:PLATFORMS,2:COUNTRIES,3:TYPES}[self.state]
            value = options[int(text)-1] if text.isdigit() and 1 <= int(text) <= len(options) else text
            if value not in options:
                return self.invalid()
            return self.offer({1:'platform',2:'country',3:'type'}[self.state], value)
        if self.state == 4:
            oid = re.search(r'订单号\s*[:：]\s*([^\n]+)', text)
            reason = re.search(r'纠纷原因\s*[:：]\s*([^\n]+)', text)
            missing = [x for x,m in [('订单号',oid),('纠纷原因',reason)] if not m]
            if missing:
                return '原文缺少：' + '、'.join(missing) + '。请在当前步补齐本单原文。'
            reason = reason.group(1).strip()
            if reason not in self.policy()['evidence_by_reason']:
                return '纠纷原因尚未对应已核对的官方类型，请补充本单通知的官方纠纷原因。'
            return self.offer('notice', {'raw': text, 'order':oid.group(1).strip(), 'reason':reason}, '订单号：' + oid.group(1).strip() + '；纠纷要点：' + reason)
        if self.state == 5:
            if not text or len(text) > 300 or text == '同上':
                return self.invalid()
            if self.field == 0 and text != self.data['notice_order']:
                return '订单号与已确认原文不一致，请核对本单订单号。'
            if any(w.casefold() in text.casefold() for ws in RISK.values() for w in ws):
                return '该值包含风险表述，请只提供本项事实，不确定可填“不确定”。'
            return self.offer(FIELDS[self.field], text)
        if self.state == 6:
            items = self.policy()['evidence_by_reason'][self.data['reason']]
            pairs = re.findall(r'(\d+)\s*=\s*(已有|待补|不适用)', text)
            if len(pairs) != len(items) or {int(i) for i,s in pairs} != set(range(1,len(items)+1)):
                return self.invalid()
            ev = {items[int(i)-1]:status for i,status in pairs}
            missing = '、'.join(k for k,v in ev.items() if v == '待补') or '无'
            return self.offer('evidence', ev, '缺项：' + missing + '。缺的证据我不会帮你编，提交前你自己补齐。')
        if self.state == 7:
            if text == '改':
                self.repair = True
                return '要改哪一项？（平台 / 国家 / 纠纷类型 / 平台原文 / 证据清单 / ' + ' / '.join(FIELDS) + '）'
            if self.repair:
                mapping = {'平台':1, '国家':2, '纠纷类型':3, '平台原文':4, '证据清单':6}
                if text in FIELDS:
                    self.field = FIELDS.index(text)
                    self.state = 5
                    self.repair_field = True
                elif text in mapping:
                    self.state = mapping[text]
                else:
                    return '要改哪一项？请从确认表项目中选择一项。'
                return self.prompt()
            if text != '确认':
                return self.invalid()
            sections = render(self.data, self.policy())
            package = '\n\n'.join(sections)
            self.ledger.consume(self.identity, self.request_id, package)
            self.sections = sections
            self.state = 9
            self.previous = {k:self.data[k] for k in ('platform','country')}
            return package
        if self.state == 9:
            if text == '就这样':
                self.state = -1
                self.data = {'facts': {}, 'evidence': {}}
                self.sections = []
                return '请你核对后自己提交，我不代提交。'
            if text in ('1','2','3','4'):
                self.revision = int(text)
                return self.prompt()
            # 这里不让自由改写绕过事实与结构。仅支持本地可证明安全的礼貌措辞。
            if self.revision and text == '更礼貌':
                idx = self.revision - 1
                new = self.sections[idx].replace('请依据', '烦请依据').replace('Please review', 'Kindly review').replace('Bitte prüfen', 'Bitte prüfen Sie')
                self.sections[idx] = new
                self.revision = None
                return new + '\n\n该段已重扫：事实值未变；' + scan(new)
            return '请指定 1–4 中的一段；本地控制器支持“更礼貌”，其他修改由团队中间层按模板校验后应用。\n' + self.prompt()
        return self.invalid()

    def accept(self, key, value):
        if self.state in (1,2,3):
            old = self.data.get(key)
            self.data[key] = value
            if self.state == 2:
                records = self.records()
                if len(records) == 4 and all(p['status'] == 'unsupported' for p in records):
                    self.state = 1
                    return '该组合暂不支持。\n' + self.prompt()
                if not any(p['status'] == 'verified' for p in records):
                    self.state = 1
                    return '该组合官方规则尚待核对，当前不能生成可提交申诉包。\n' + self.prompt()
            if self.state == 3 and (not self.policy() or self.policy()['status'] != 'verified'):
                status = (self.policy() or {}).get('status')
                self.state = 1
                return ('该组合暂不支持。' if status == 'unsupported' else '该组合官方规则尚待核对，当前不能生成可提交申诉包。') + '\n' + self.prompt()
            if self.repair:
                # 选择器变更需重核对依赖，不复用旧规则或证据。
                if old != value:
                    self.data.pop('reason', None)
                    self.data['evidence'] = {}
                    self.repair = False
                    self.state += 1
                else:
                    self.repair = False
                    self.state = 7
            else:
                self.state += 1
        elif self.state == 4:
            self.data.update(notice=value['raw'], notice_order=value['order'], reason=value['reason'])
            self.field = 0
            if self.repair:
                self.data['evidence'] = {}
                self.repair = False
            self.state = 5
        elif self.state == 5:
            self.data['facts'][key] = value
            if self.repair_field:
                self.repair_field = self.repair = False
                self.state = 7
            elif self.field < 6:
                self.field += 1
            else:
                self.state = 6
        elif self.state == 6:
            self.data['evidence'] = value
            self.repair = False
            self.state = 7
        return self.prompt()


def render(data, policy):
    if not policy or policy['status'] != 'verified':
        raise ValueError('官方规则尚待核对')
    facts, ev = data['facts'], data['evidence']
    if set(facts) != set(FIELDS) or not ev:
        raise ValueError('事实或证据确认未完成')
    rows = []
    available = []
    for i,(name,status) in enumerate(ev.items(),1):
        item = f'E{i} {safe(name)}'
        rows.append('|' + '|'.join(item if status == s else '—' for s in ('已有','待补','不适用')) + '|')
        if status == '已有':
            available.append(f'E{i} {safe(name)}')
    evidence = '## 1. 证据清单\n\n|已有|待补|不适用|\n|---|---|---|\n' + '\n'.join(rows)
    values = [safe(facts[k]) for k in FIELDS]
    labels = ['Order','Amount','Dispatched','Delivered','Tracking number','Return status','Refund status']
    de = data['country'] == '德国'
    if de:
        labels = ['Bestellung','Betrag','Versandt','Zugestellt','Sendungsnummer','Rücksendestatus','Erstattungsstatus']
    elif data['country'] == '美国':
        labels[2] = 'Shipped'
    foreign = '; '.join(f'{label}: {value}' for label,value in zip(labels,values))
    # 固定双语标签，不把原始证据/买家文字当指令或事实写入。
    reason_labels = policy.get('reason_labels', {}).get(data['reason'], {})
    reason_foreign = reason_labels.get('de' if de else 'en')
    evidence_labels = policy.get('evidence_labels', {})
    if not reason_foreign or any(k not in evidence_labels or ('de' if de else 'en') not in evidence_labels[k] for k in ev):
        raise ValueError('官方类型或证据语言标签尚待核对')
    refs_foreign = ', '.join(f'E{i} {safe(evidence_labels[k]["de" if de else "en"])}' for i,(k,v) in enumerate(ev.items(),1) if v == '已有')
    refs_cn = '、'.join(available) or '无已确认的已有证据；缺项待补'
    if de:
        body = foreign + '\n\nStreitpunkt: ' + safe(reason_foreign) + '\n\nAls vorhanden bestätigte Originalbelege: ' + (refs_foreign or 'Keine; fehlende Belege sind nachzureichen.') + '\n\nBitte prüfen Sie den Vorgang anhand der bestätigten Angaben und Originalbelege.\n\nVielen Dank für Ihre Prüfung.'
    else:
        body = foreign + '\n\nDispute: ' + safe(reason_foreign) + '\n\nOriginal evidence confirmed as available: ' + (refs_foreign or 'None; missing evidence remains to be supplied.') + '\n\nPlease review this case based on the confirmed facts and original evidence.\n\nThank you for your review.'
    cn = '；'.join(f'{k}：{safe(facts[k])}' for k in FIELDS) + '\n\n争议点：' + safe(data['reason']) + '\n\n已确认持有的原始证据：' + refs_cn + '\n\n请依据已确认事实和原始证据复核本案。\n\n感谢您的审阅。'
    letter = '## 2. 申诉信草稿\n\n### 平台语言正文\n\n' + body + '\n\n### 中文对照\n\n' + cn
    risk = '## 3. 禁用语与风险自查\n\n' + scan(data['notice'] + '\n' + body) + '\n\n风险提示：缺的证据我不会帮你编，提交前你自己补齐。未知值保持原样，不作法律定性，不承诺结果。'
    checklist = '## 4. 提交核对表\n\n|核对项|内容|\n|---|---|\n|后台入口|' + safe(policy['entry']) + '|\n|附带文件|' + refs_cn + '|\n|截止时间|以平台通知为准；未提供具体截止时间，须本人核对通知|\n|提交前|原始未编辑文件；金额、订单号、时间逐字核对；待补先补齐|\n|提交后留存|回执、案件编号、提交时间、原始文件副本、平台回复|\n\n请你核对后自己提交，我不代提交。'
    return [evidence, letter, risk, checklist]
