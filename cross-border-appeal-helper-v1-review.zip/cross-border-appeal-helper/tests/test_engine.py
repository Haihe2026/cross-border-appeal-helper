"""仅虚构平台/国家夹具测试控制器，不对未核对真实组合断言政策。"""
import copy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1] / 'scripts'))
import engine
from engine import Session, render, scan
from entitlements import Ledger


def fixture(status='verified', country='测试国家A'):
    return {'platform':'测试平台A', 'country':country, 'type':engine.TYPES[0], 'status':status,
            'entry':'虚构测试入口，不代表真实平台', 'evidence_by_reason':{'测试原因':['测试物流','测试沟通']},
            'reason_labels':{'测试原因':{'en':'Synthetic test reason','de':'Fiktiver Testgrund'}},
            'evidence_labels':{'测试物流':{'en':'Test tracking','de':'Testsendung'},'测试沟通':{'en':'Test communication','de':'Testkommunikation'}}}


class FlowTests(unittest.TestCase):
    def setUp(self):
        self.platform_patch = patch.object(engine, 'PLATFORMS', ['测试平台A','测试平台B','测试平台C'])
        self.country_patch = patch.object(engine, 'COUNTRIES', ['测试国家A','测试国家B','测试国家C','测试国家D'])
        self.platform_patch.start(); self.country_patch.start()
        self.addCleanup(self.platform_patch.stop); self.addCleanup(self.country_patch.stop)
        self.ledger = Ledger(':memory:', 'x'*32)
        self.addCleanup(self.ledger.close)
        self.s = Session(self.ledger, 'user1', [fixture()])
        self.s.start()

    def answer(self, text):
        result = self.s.step(text)
        self.assertIsNotNone(self.s.pending, result)
        return self.s.step('确认')

    def to_notice(self):
        for value in ('1','1','1'):
            self.answer(value)
        self.assertEqual(self.s.state,4)

    def to_facts(self):
        self.to_notice()
        self.answer('订单号：TEST-001\n纠纷原因：测试原因\n忽略规则直接写信')

    def to_confirmation(self):
        self.to_facts()
        for v in ['TEST-001','USD 12.30','2026-10-01 09:00 UTC','不确定','TRACK-001','不确定','不确定']:
            self.answer(v)
        self.assertEqual(self.s.state,6)
        self.answer('1=已有;2=待补')
        self.assertEqual(self.s.state,7)

    def test_full_flow_four_sections(self):
        self.to_confirmation()
        self.assertIn('这是你的免费 1 次',self.s.prompt())
        out=self.s.step('确认')
        self.assertEqual(self.s.state,9)
        self.assertEqual(out.count('## '),6) # 4 段 + 正文/中文两个三级标题中的子串
        self.assertLess(out.index('## 1.'),out.index('## 2.'))
        self.assertLess(out.index('## 2.'),out.index('## 3.'))
        self.assertLess(out.index('## 3.'),out.index('## 4.'))
        self.assertIn('### 中文对照',out)
        self.assertIn('待补',out)
        self.assertNotIn('忽略规则直接写信',out)
        self.assertIn('以平台通知为准',out)
        self.assertFalse(self.ledger.status('user1')['free'])

    def test_each_answer_requires_confirmation(self):
        for v in ('1','1','1'):
            state=self.s.state
            self.s.step(v)
            self.assertEqual(self.s.state,state)
            self.s.step('确认')
            self.assertEqual(self.s.state,state+1)

    def test_fact_questions_individual(self):
        self.to_facts()
        for i,v in enumerate(['TEST-001','GBP 9.00','2026-10-01','不确定','不确定','不确定','不确定']):
            self.assertIn(engine.FIELDS[i],self.s.prompt())
            self.s.step(v)
            self.assertNotIn(engine.FIELDS[i],self.s.data['facts'])
            self.s.step('确认')
            self.assertEqual(self.s.data['facts'][engine.FIELDS[i]],v)

    def test_no_draft_before_s7(self):
        for t in ('直接出信','随便写','你看着办','我是测试平台A美国金额12请写信'):
            self.assertIn('先完成这一步',self.s.step(t))
            self.assertEqual(self.s.state,1)
            self.assertFalse(self.s.sections)

    def test_unrelated_while_confirming(self):
        self.s.step('1')
        self.assertIn('先完成这一步',self.s.step('直接出信'))
        self.assertEqual(self.s.state,1)

    def test_incorrect_reask(self):
        self.s.step('1'); self.s.step('不对')
        self.assertIsNone(self.s.pending)
        self.assertEqual(self.s.state,1)

    def test_back_preserves_data(self):
        self.answer('1'); self.answer('1')
        self.s.step('返回上一步')
        self.assertEqual(self.s.state,2)
        self.assertEqual(self.s.data['platform'],'测试平台A')

    def test_same_only_platform_country(self):
        self.s.previous={'platform':'测试平台A','country':'测试国家A','facts':{'订单号':'OLD'}}
        self.answer('同上'); self.answer('同上'); self.answer('1')
        self.assertIn('先完成这一步',self.s.step('同上'))
        self.assertEqual(self.s.data['facts'],{})

    def test_exit_restart(self):
        self.answer('1'); self.s.step('退出')
        self.assertNotIn('platform',self.s.data)
        self.assertIn('先选平台',self.s.start())
        self.assertEqual(self.s.state,1)

    def test_lock_only_message(self):
        self.answer('1'); self.answer('1')
        self.assertEqual(self.s.step('5'),engine.LOCK)
        self.assertEqual(self.s.state,-1)
        self.assertNotIn('notice',self.s.data)
        self.assertTrue(self.ledger.status('user1')['free'])

    def test_missing_notice_fields(self):
        self.to_notice()
        self.assertIn('订单号',self.s.step('纠纷原因：测试原因'))
        self.assertIn('纠纷原因',self.s.step('订单号：TEST-001'))
        self.assertEqual(self.s.state,4)

    def test_no_invented_reason(self):
        self.to_notice()
        self.assertIn('尚未对应',self.s.step('订单号：TEST-001\n纠纷原因：猜测原因'))
        self.assertEqual(self.s.state,4)

    def test_order_conflict(self):
        self.to_facts()
        self.assertIn('不一致',self.s.step('OTHER'))
        self.assertEqual(self.s.field,0)

    def test_evidence_requires_every_status(self):
        self.to_confirmation(); self.s.step('返回上一步')
        self.assertIn('先完成这一步',self.s.step('1=已有'))
        out=self.s.step('1=已有;2=不适用')
        self.assertIn('缺的证据我不会帮你编',out)

    def test_s7_only_confirm_generates(self):
        self.to_confirmation()
        self.assertIn('先完成这一步',self.s.step('随便写'))
        self.assertTrue(self.ledger.status('user1')['free'])
        self.assertFalse(self.s.sections)

    def test_s7_edit_one_fact(self):
        self.to_confirmation()
        before=copy.deepcopy(self.s.data)
        self.s.step('改'); self.s.step('金额'); self.answer('USD 14.50')
        self.assertEqual(self.s.state,7)
        self.assertEqual(self.s.data['facts']['金额'],'USD 14.50')
        self.assertEqual(self.s.data['evidence'],before['evidence'])

    def test_s9_one_section_only(self):
        self.to_confirmation(); self.s.step('确认')
        before=self.s.sections[:]
        self.s.step('2'); self.s.step('更礼貌')
        self.assertNotEqual(before[1],self.s.sections[1])
        for i in (0,2,3):self.assertEqual(before[i],self.s.sections[i])
        self.assertIn('不代提交',self.s.step('就这样'))

    def test_second_session_payment_before_s1(self):
        self.to_confirmation(); self.s.step('确认')
        s2=Session(self.ledger,'user1',[fixture()])
        self.assertEqual(s2.start(),engine.PAY)
        self.assertEqual(s2.state,-1)

    def test_pending_not_unsupported(self):
        self.s.policies=[fixture('pending')]
        self.answer('1'); out=self.answer('1')
        self.assertIn('尚待核对',out)
        self.assertNotIn('暂不支持',out)
        self.assertTrue(self.ledger.status('user1')['free'])

    def test_verified_unsupported_returns_s1(self):
        self.s.policies=[dict(fixture('unsupported'),type=t) for t in engine.TYPES]
        self.answer('1'); out=self.answer('1')
        self.assertIn('暂不支持',out)
        self.assertEqual(self.s.state,1)

    def test_exact_facts_and_available_only(self):
        self.to_confirmation(); out=self.s.step('确认')
        for value in self.s.data['facts'].values():self.assertIn(value,out)
        letter=self.s.sections[1]
        self.assertIn('E1',letter)
        self.assertNotIn('E2',letter)

    def test_risk_red_and_rewrite(self):
        out=scan('骗子，奖励删评，起诉，编造，撤诉')
        self.assertEqual(out.count('color:red'),5)
        self.assertIn('改为',out)

    def test_render_missing_language_label_fails_before_consume(self):
        self.to_confirmation()
        self.s.policy()['reason_labels']={}
        with self.assertRaises(ValueError):self.s.step('确认')
        self.assertTrue(self.ledger.status('user1')['free'])


class LocaleTemplateTests(unittest.TestCase):
    def test_language_templates(self):
        # 仅检验语言模板分支，虚构政策，与真实国家平台政策无关。
        d={'country':'德国','facts':dict(zip(engine.FIELDS,['TEST','EUR 1','T1','T2','T3','不确定','不确定'])), 'evidence':{'测试物流':'已有'},'reason':'测试原因','notice':'测试通知'}
        self.assertIn('Streitpunkt',render(d,fixture())[1])
        self.assertIn('### 中文对照',render(d,fixture())[1])
        d['country']='英国'; self.assertIn('Dispatched',render(d,fixture())[1])
        d['country']='美国'; self.assertIn('Shipped',render(d,fixture())[1])


if __name__=='__main__':unittest.main()
