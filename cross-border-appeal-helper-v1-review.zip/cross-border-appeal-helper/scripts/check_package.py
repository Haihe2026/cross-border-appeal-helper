import json
from pathlib import Path

ROOT = Path(__file__).parents[1]
ALLOWED = {'.md', '.json', '.py', '.svg', '.txt', '.csv'}


def check(root=ROOT):
    errors = []
    skill = (root / 'SKILL.md').read_text()
    if not skill.startswith('---\n') or '\nname:' not in skill.split('---')[1] or '\ndescription:' not in skill.split('---')[1]:
        errors.append('SKILL.md YAML 头缺失')
    for f in root.rglob('*'):
        if '__pycache__' in f.parts:
            continue  # 打包程序排除，运行测试会在工作区生成
        if any(p.startswith('.') for p in f.relative_to(root).parts):
            errors.append('隐藏路径：' + str(f))
        if f.is_file() and f.suffix not in ALLOWED:
            errors.append('未允许扩展名：' + str(f))
    records = json.loads((root / 'references/policies.json').read_text())
    keys = {(r['platform'], r['country'], r['type']) for r in records}
    if len(records) != 48 or len(keys) != 48:
        errors.append('政策核对库应有 48 个独立主键')
    from engine import PLATFORMS, COUNTRIES, TYPES
    expected = {(p,c,t) for p in PLATFORMS for c in COUNTRIES for t in TYPES}
    if keys != expected:
        errors.append('平台×国家×类型覆盖不完整')
    for r in records:
        if r['status'] not in ('pending','verified','unsupported'):
            errors.append('无效核对状态')
        if r['status'] in ('verified','unsupported'):
            required = ['source_url','source_title','checked_at','reviewer','source_excerpt','source_sha256']
            if any(not r.get(k) for k in required):
                errors.append('缺官方核对来源')
        if r['status'] == 'verified' and any(not r.get(k) for k in ('deadline_text','entry','evidence_by_reason','reason_labels','evidence_labels')):
            errors.append('政策字段或语言标签未齐全')
    return errors


if __name__ == '__main__':
    errors = check()
    print('\n'.join(errors) if errors else '本地结构检查通过；不代表官方平台白名单认证。')
    raise SystemExit(bool(errors))
