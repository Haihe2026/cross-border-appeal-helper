"""构建本地归档；不含任何网络或上传操作。"""
import argparse
import hashlib
from pathlib import Path
import zipfile
from check_package import ALLOWED, ROOT, check


def build(target):
    errors = check()
    if errors:
        raise ValueError('\n'.join(errors))
    target = Path(target).resolve()
    if ROOT == target or ROOT in target.parents:
        raise ValueError('归档须放在技能目录外')
    files = []
    for p in sorted(ROOT.rglob('*')):
        rel = p.relative_to(ROOT)
        if '__pycache__' in rel.parts or any(x.startswith('.') for x in rel.parts):
            continue
        if p.is_symlink():
            raise ValueError('不允许符号链接')
        if p.is_file():
            if p.suffix not in ALLOWED:
                raise ValueError('存在未允许扩展名')
            files.append(p)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:
            info = zipfile.ZipInfo(ROOT.name + '/' + p.relative_to(ROOT).as_posix(), date_time=(2026,10,31,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info,p.read_bytes())
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None or len(z.namelist()) != len(files):
            raise ValueError('归档完整性检查失败')
        for f in files:
            if z.read(ROOT.name+'/'+f.relative_to(ROOT).as_posix()) != f.read_bytes():
                raise ValueError('归档内容不一致')
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix(target.suffix+'.sha256.txt').write_text(digest+'  '+target.name+'\n')
    print(f'{target}\n文件数：{len(files)}\nSHA256：{digest}')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',required=True)
    build(parser.parse_args().out)
