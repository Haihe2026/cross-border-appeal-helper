"""无网络干净目录重跑；不触发任何托管 CI 或仓库。"""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).parents[1]
with tempfile.TemporaryDirectory(prefix='appeal-clean-') as tmp:
    dest = Path(tmp) / root.name
    shutil.copytree(root, dest, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'}
    for command in ([sys.executable, 'scripts/check_package.py'], [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v']):
        result = subprocess.run(command, cwd=dest, env=env, check=False)
        if result.returncode:
            raise SystemExit(result.returncode)
print('干净目录本地 CI 重跑通过。')
