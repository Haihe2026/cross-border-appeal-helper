# 官方资料实际检索记录

核对日期：2026-10-31（用户时区）。实际完成公开网页搜索及下列页面打开；不是仅凭记忆填规则。执行环境直连白名单限制仍在，独立网页工具可取得部分公开资料。搜索摘要不能替代完整适用政策，论坛讨论不作为官方政策正文。

|平台/国家|资料|实际结果及范围|
|---|---|---|
|Amazon US|[A-to-z appeal 帮助页](https://sellercentral.amazon.com/help/hub/reference/external/G202041210)|打开返回登录/JavaScript 外壳，不能核对证据与完整入口；保持 pending|
|Amazon UK|[Feedback 帮助页候选](https://sellercentral.amazon.co.uk/help/hub/reference/external/G20231)|打开返回登录/JavaScript 外壳，未用其他国家标准填充；保持 pending|
|Amazon UK|[A-to-z appeal 帮助页候选](https://sellercentral.amazon.co.uk/help/hub/reference/external/G202041210)|搜索可见摘要，未取完整正文；不能按摘要启用|
|Amazon DE|[A-bis-z appeal 帮助页候选](https://sellercentral.amazon.de/help/hub/reference/external/G202041210)|搜索命中；[SAFE-T 候选](https://sellercentral.amazon.de/help/hub/reference/external/G202175000)另需核对项目资格；未拼用跨国规则|
|Amazon AU|[卖家协议候选](https://sellercentral.amazon.com.au/gp/help/external/1791?language=en_AU)|搜索命中协议与论坛，未取得覆盖四类的适用帮助正文；保持 pending|
|TikTok Shop US|[Requirements for After-sales Dispute Escalations](https://seller-us.tiktok.com/university/essay?knowledge_id=3985068541478658)|已打开官方正文，明确适用于美国。可见争议入口与若干情景，但尚未逐项完成全部子类型、限制及初始证据映射，因此记录部分核对而不启用整类|
|TikTok Shop US|[After-Sales Evidence Guide for Appeals and Disputes](https://seller-us.tiktok.com/university/essay?knowledge_id=7042659022210829)|已打开官方正文；不同情景要求不同材料，强调原始、连续的打包/开箱证明。需要逐项映射全部适用情景，不能用通用清单声称齐全|
|TikTok Shop US|[Appeal Return/Refund Orders in Seller Center](https://seller-us.tiktok.com/university/essay?knowledge_id=8338237340780289)|已打开官方正文；适用退货退款申诉而非账号解封。尚未核对完整时限与全部条件；保持 pending|
|TikTok Shop UK|[Aftersale Dispute Escalation Policy](https://seller-uk.tiktok.com/university/essay?knowledge_id=328289274038038&lang=en-GB)、[returned packages](https://seller-uk.tiktok.com/university/essay?knowledge_id=8253360776136450)、[chargeback](https://seller-uk.tiktok.com/university/essay?knowledge_id=8617626885621537&lang=en-GB)|搜索命中英国官方候选；未完整打开核对，保持 pending，不套美国|
|TikTok Shop DE|[退回包裹与申诉候选](https://seller-de.tiktok.com/university/essay?knowledge_id=606670371948320&lang=de-DE)、[拒付候选](https://seller-de.tiktok.com/university/essay?knowledge_id=8867193686132502)|搜索命中德国官方候选；未完整核对，不套英国或美国|
|TikTok Shop AU|搜索 seller-au 官方售后、争议及申诉资料|未取得足以核实澳洲通道的官方原文；“未取得”不等于“不支持”|
|Temu US/UK/DE|检索官方卖家中心与各国售后申诉/证据/退款规则|结果含登录页、消费者条款及消费者退款帮助；不拿消费者规则当卖家申诉通道，保持 pending|
|Temu AU|[Australia Seller Center](https://au.seller.temu.com/login.html)|已打开；仅有注册登录及营销内容，无可核对的订单申诉时限、证据、入口；保持 pending，未判定无通道|

## 还没有完成的核对

policies.json 与 policy-audit.csv 列出所有 48 行。未将论坛、搜索摘要、消费者协议或美国政策提升为其他国家的 verified。没有写死数字时限，没有对 Temu 澳洲假设“不支持”。完整官方正文、适用国家/项目、各情景证据、正式后台入口逐项核实后才能启用相应记录。
