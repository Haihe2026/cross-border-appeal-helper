"""本地 JSONL/交互控制器；不连接支付平台，不上传。"""
import argparse
import os
from engine import Session
from entitlements import Ledger


def main():
    p = argparse.ArgumentParser(description='跨境售后申诉助手本地接线工具')
    p.add_argument('--identity', required=True, help='仅本地演示；生产身份须由可信中间层认证注入')
    p.add_argument('--database', required=True, help='自有后端数据库路径，不放入技能包')
    args = p.parse_args()
    secret = os.environ.get('APPEAL_IDENTITY_KEY', '')
    if len(secret) < 32:
        print('请先配置长度至少 32 的本地身份密钥；生产使用后端密钥管理。')
        return 2
    ledger = Ledger(args.database, secret)
    try:
        session = Session(ledger, args.identity)
        print(session.start())
        while session.state > 0:
            try:
                # 单行输入中的字面 \\n 转为原文换行；不保存日志。
                value = input('> ').replace('\\n', '\n')
            except EOFError:
                session.step('退出')
                break
            print(session.step(value))
    except Exception:
        print('当前无法继续，请稍后重试或联系团队管理员。')
        return 1
    finally:
        ledger.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
