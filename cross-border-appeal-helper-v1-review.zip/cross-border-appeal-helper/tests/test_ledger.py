import concurrent.futures
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from entitlements import Ledger


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.l=Ledger(':memory:','x'*32)
        self.addCleanup(self.l.close)

    def test_consume_once_and_idempotency(self):
        self.l.consume('u','r1','four sections')
        self.l.consume('u','r1','four sections')
        self.assertEqual(self.l.db.execute('SELECT COUNT(*) FROM events').fetchone()[0],1)
        with self.assertRaises(PermissionError):self.l.consume('u','r2','four sections')

    def test_same_request_different_content_rejected(self):
        self.l.consume('u','r','a')
        with self.assertRaises(ValueError):self.l.consume('u','r','b')
        with self.assertRaises(ValueError):self.l.consume('v','r','a')

    def test_grant_idempotency(self):
        self.l.grant('u','pay1',2); self.l.grant('u','pay1',2)
        self.assertEqual(self.l.status('u')['credits'],2)
        self.l.consume('u','r1','a')
        self.assertEqual(self.l.status('u')['credits'],2)
        self.l.consume('u','r2','a')
        self.assertEqual(self.l.status('u')['credits'],1)
        with self.assertRaises(ValueError):self.l.grant('v','pay1',2)

    def test_identity_and_secret_validation(self):
        with self.assertRaises(ValueError):Ledger(':memory:','short')
        with self.assertRaises(ValueError):self.l.status('')

    def test_no_case_content_in_ledger(self):
        self.l.consume('raw-user-identity','r','private-order-message')
        dump=''.join(self.l.db.iterdump())
        self.assertNotIn('raw-user-identity',dump)
        self.assertNotIn('private-order-message',dump)

    def test_persistence_and_concurrent_free_race(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=str(Path(tmp)/'ledger.sqlite3')
            boot=Ledger(path,'x'*32); boot.close()
            def consume(i):
                local=Ledger(path,'x'*32)
                try:
                    local.consume('u',f'r{i}','package')
                    return True
                except PermissionError:return False
                finally:local.close()
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                results=list(pool.map(consume,range(8)))
            self.assertEqual(sum(results),1)
            check=Ledger(path,'x'*32)
            try:self.assertFalse(check.status('u')['free'])
            finally:check.close()


if __name__=='__main__':unittest.main()
