# 官方政策核对与启用

第一项工作已对 3×4×4=48 个记录建库逐项标出需要核对的时限、证据、入口。执行环境 HTTP 白名单没有三个平台卖家中心；随后通过独立网页检索补查，取得部分 TikTok Shop 官方正文、Amazon 帮助页候选链接及 Temu 登录页，但尚不足以逐条确认全部时限、证据和入口。所有记录仍是 pending，**不是 verified，也不是 unsupported**。详见 official-source-log.md。本包不提供任何未经核对的政策断言。没有借用其他国家规则，没有数字时限。

核对员按平台×国家×类型分别从官方卖家中心定位原文。记录 URL、标题、国家适用范围、官方类型名、访问时间、原文节选、原文 SHA256、时限原句、证据原句、入口原句；需登录时由卖家本人导出脱敏政策，不索要凭证。不以论坛、第三方文章替代官方。证实无通道才用 unsupported，必须留官方依据。

核对每条第 7 节初始证据是否适用。对 S3 平台索赔再记录官方子类型到 evidence_by_reason，不能自造平台类型。类型与国家都匹配后才设 verified；其余保持 pending。更新后审阅人填 reviewer，二次校验并重新跑针对**该条已核对**政策的真实样本测试；当前测试不对这 48 条的时限、入口或支持性作断言。

库字段：platform/country/type/status/source_url/source_title/checked_at/reviewer/source_excerpt/source_sha256/deadline_text/entry/evidence_by_reason。截止时间所有输出一律加“以平台通知为准”；实际订单通知优先核对，不从样本计算。状态 pending 暂停该条生成；unsupported 在 S2（整组合无任何通道）或 S3（该类型无通道）返回 S1，明确暂不支持；不能把未知当不存在。
