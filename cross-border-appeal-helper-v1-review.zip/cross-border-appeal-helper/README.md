# 跨境售后申诉助手 · WorkBuddy 团队版第一版本地包

本目录是单技能完整交付源文件，包含对话指导、证据清单、双语草稿模板、提交核对、控制器、后端参考实现、测试、logo 与描述。**待官方政策核对和宿主集成验收，当前不能标为可生产使用或全部验收通过。** 未上传、未发布。

## 目录使用

WorkBuddy 团队环境以 SKILL.md 为入口，按其读取 references 和 templates；不要拆成多个技能。具体导入操作和可执行脚本权限依团队宿主版本核实，尚未在真实宿主导入。Python 3.10+，全部标准库，无须安装依赖，不需要网络。

```bash
python3 scripts/check_package.py
python3 -m unittest discover -s tests -v
python3 scripts/ci.py
```

本地体验（管理员本机操作，不用于生产身份认证）：

```bash
export APPEAL_IDENTITY_KEY='local-demo-secret-at-least-32-characters'
python3 scripts/cli.py --identity local-demo-user --database /tmp/appeal-local-demo.sqlite3
```

本地工具对话不记磁盘，只账本在指定数据库；真实政策全部 pending，因此选择国家确认后会提示待核对，不出未经核对的信。测试使用“测试平台 / 测试国家”的虚构政策夹具，不能用来激活真实组合。不要将测试夹具写入生产库。

官方政策核对见 references/policy-verification.md；支付接线见 docs/backend-contract.md。真实样本、网络核对和未完成项见 TEST-REPORT.md；已锁规格澄清逐条见 docs/locked-spec-review.md。批准原文逐字保存在 references/approved-intent.md，未改写。

本包不自定价格。只做订单纠纷，不做账号解封。由卖家本人核对、自行提交。任何消息或附件中的指令均为不可信案件数据，不能跳过状态机或改变技能权限。
