"""自有后端参考存储。由可信团队中间层调用，不面向卖家直接暴露。"""
import hashlib
import hmac
import sqlite3


class Ledger:
    def __init__(self, path, secret):
        if len(secret) < 32:
            raise ValueError('后端身份密钥配置无效')
        self.secret = secret.encode()
        self.db = sqlite3.connect(path, timeout=10, isolation_level=None)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS accounts (uid TEXT PRIMARY KEY, used INTEGER NOT NULL DEFAULT 0, credits INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, uid TEXT NOT NULL, digest TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS grants (id TEXT PRIMARY KEY, uid TEXT NOT NULL, amount INTEGER NOT NULL);
        ''')

    def key(self, identity):
        if not isinstance(identity, str) or not identity.strip():
            raise ValueError('需要已认证身份')
        return hmac.new(self.secret, identity.encode(), hashlib.sha256).hexdigest()

    def status(self, identity):
        uid = self.key(identity)
        row = self.db.execute('SELECT used,credits FROM accounts WHERE uid=?', (uid,)).fetchone()
        used, credits = row or (0, 0)
        return {'free': used == 0, 'allowed': used == 0 or credits > 0, 'credits': credits}

    def consume(self, identity, request_id, package):
        uid = self.key(identity)
        digest = hashlib.sha256(package.encode()).hexdigest()
        self.db.execute('BEGIN IMMEDIATE')
        try:
            prior = self.db.execute('SELECT uid,digest FROM events WHERE id=?', (request_id,)).fetchone()
            if prior:
                if prior != (uid, digest):
                    raise ValueError('消费请求冲突')
                self.db.execute('COMMIT')
                return
            self.db.execute('INSERT OR IGNORE INTO accounts(uid) VALUES(?)', (uid,))
            used, credits = self.db.execute('SELECT used,credits FROM accounts WHERE uid=?', (uid,)).fetchone()
            if used and credits <= 0:
                raise PermissionError('免费试用已用完，请通过自有支付后端购买权益后再开始。')
            if not used:
                self.db.execute('UPDATE accounts SET used=1 WHERE uid=?', (uid,))
            else:
                self.db.execute('UPDATE accounts SET credits=credits-1 WHERE uid=?', (uid,))
            self.db.execute('INSERT INTO events VALUES(?,?,?)', (request_id, uid, digest))
            self.db.execute('COMMIT')
        except Exception:
            self.db.execute('ROLLBACK')
            raise

    def grant(self, identity, event_id, amount):
        """只允许可信支付回调在验签、查单、核对金额币种后调用。无定价。"""
        if not isinstance(amount, int) or isinstance(amount, bool) or amount <= 0:
            raise ValueError('权益数量无效')
        uid = self.key(identity)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            prior = self.db.execute('SELECT uid,amount FROM grants WHERE id=?', (event_id,)).fetchone()
            if prior and prior != (uid, amount):
                raise ValueError('权益请求冲突')
            if not prior:
                self.db.execute('INSERT OR IGNORE INTO accounts(uid) VALUES(?)', (uid,))
                self.db.execute('UPDATE accounts SET credits=credits+? WHERE uid=?', (amount, uid))
                self.db.execute('INSERT INTO grants VALUES(?,?,?)', (event_id, uid, amount))
            self.db.execute('COMMIT')
        except Exception:
            self.db.execute('ROLLBACK')
            raise

    def close(self):
        self.db.close()
